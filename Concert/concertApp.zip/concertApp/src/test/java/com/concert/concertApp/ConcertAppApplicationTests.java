package com.concert.concertApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcertAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
