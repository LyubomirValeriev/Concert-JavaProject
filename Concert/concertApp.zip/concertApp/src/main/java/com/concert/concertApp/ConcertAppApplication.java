package com.concert.concertApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConcertAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConcertAppApplication.class, args);
	}

}
