package com.concert.concertApp.entities;

public class ConcertHall {
}
